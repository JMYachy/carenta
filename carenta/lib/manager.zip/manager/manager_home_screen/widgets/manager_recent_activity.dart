import 'package:flutter/material.dart';

class ManagerRecentActivitySection extends StatelessWidget {
  final List<Map<String, dynamic>> activities;

  const ManagerRecentActivitySection({super.key, required this.activities});

  @override
  Widget build(BuildContext context) {
    if (activities.isEmpty) {
      return const Text("No recent activity found.",
          style: TextStyle(color: Colors.black54));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Recent Activities",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Color(0xFF0077B6),
          ),
        ),
        const SizedBox(height: 10),
        ListView.builder(
          itemCount: activities.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, i) {
            final a = activities[i];
            return ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                backgroundColor: _getColorForType(a['event']).withOpacity(0.15),
                child: Icon(_getIconForType(a['event']),
                    color: _getColorForType(a['event'])),
              ),
              title: Text(a['event'] ?? '-', style: const TextStyle(fontWeight: FontWeight.w500)),
              subtitle: Text(a['time'] ?? '-',
                  style: const TextStyle(fontSize: 12, color: Colors.black54)),
            );
          },
        ),
      ],
    );
  }

  IconData _getIconForType(String? event) {
    if (event == null) return Icons.notifications;
    if (event.toLowerCase().contains('rental')) return Icons.car_rental;
    if (event.toLowerCase().contains('payment')) return Icons.payments;
    return Icons.notifications;
  }

  Color _getColorForType(String? event) {
    if (event == null) return Colors.grey;
    if (event.toLowerCase().contains('rental')) return Colors.blueAccent;
    if (event.toLowerCase().contains('payment')) return Colors.green;
    return Colors.grey;
  }
}
