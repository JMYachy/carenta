import 'package:flutter/material.dart';

class ManagerQuickAction extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final String route;

  const ManagerQuickAction(this.label, this.icon, this.color, this.route, {super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.pushNamed(context, route),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 160,
        height: 120,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 36),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.w600, color: color, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}
