import 'package:flutter/material.dart';

class ManagerHomeScreen extends StatelessWidget {
  final int pendingVerifications;
  final int availableCars;
  final int activeRentals;
  final int bookingsToday;

  const ManagerHomeScreen({
    super.key,
    required this.pendingVerifications,
    required this.availableCars,
    required this.activeRentals,
    required this.bookingsToday,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 10),
          const Text(
            "Manager Dashboard",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Color(0xFF0077B6),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Overview of today’s operations",
            style: TextStyle(fontSize: 16, color: Colors.black54),
          ),
          const SizedBox(height: 24),

          // 📊 Stats Grid
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            children: [
              _buildStat("Pending Verifications", pendingVerifications, Icons.verified_user, Colors.orangeAccent),
              _buildStat("Available Cars", availableCars, Icons.directions_car, Colors.lightBlueAccent),
              _buildStat("Active Rentals", activeRentals, Icons.assignment, Colors.greenAccent),
              _buildStat("Bookings Today", bookingsToday, Icons.calendar_today, Colors.purpleAccent),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStat(String title, int value, IconData icon, Color color) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundColor: color.withOpacity(0.2),
              child: Icon(icon, color: color),
            ),
            const SizedBox(height: 10),
            Text("$value",
                style: const TextStyle(
                    fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14, color: Colors.black54)),
          ],
        ),
      ),
    );
  }
}
