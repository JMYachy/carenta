import 'package:carenta/Admin/car_management/car_detail_screen.dart';
import 'package:carenta/widget/shared/car_card_widget.dart';
import 'package:flutter/material.dart';
import 'package:carenta/service/Shared/get_car_service.dart';
import 'package:carenta/widget/admin_widget/car_model.dart';
import 'package:carenta/Admin/car_management/add_car.dart';

class ManagerCarScreen extends StatefulWidget {
  const ManagerCarScreen({super.key});

  @override
  State<ManagerCarScreen> createState() => _ManagerCarScreenState();
}

class _ManagerCarScreenState extends State<ManagerCarScreen> {
  final GetCarService _carService = GetCarService();
  final TextEditingController _searchController = TextEditingController();

  List<Map<String, dynamic>> _cars = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadCars();
  }

  Future<void> _loadCars() async {
    setState(() => _loading = true);
    try {
      final result = await _carService.getCars();
      final List<Map<String, dynamic>> cars =
          List<Map<String, dynamic>>.from(result);
      setState(() {
        _cars = cars;
        _filtered = cars;
        _loading = false;
      });
    } catch (e) {
      debugPrint("❌ Error loading cars: $e");
      setState(() => _loading = false);
    }
  }

  void _filter(String query) {
    final lower = query.toLowerCase();
    setState(() {
      _filtered = _cars.where((car) {
        final manufacturer =
            (car['manufacturer'] ?? '').toString().toLowerCase();
        final model = (car['model'] ?? '').toString().toLowerCase();
        final license = (car['license_plate'] ?? '').toString().toLowerCase();
        return manufacturer.contains(lower) ||
            model.contains(lower) ||
            license.contains(lower);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = const Color(0xFF0077B6);

    return Column(
      children: [
        // 🔍 Search & Add Car
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onChanged: _filter,
                  decoration: InputDecoration(
                    hintText: 'Search cars...',
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding:
                        const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              IconButton(
                icon: Icon(Icons.add_circle, color: themeColor, size: 32),
                tooltip: 'Add Car',
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AddCar()),
                  );
                  _loadCars();
                },
              ),
            ],
          ),
        ),

        // 🚗 Car List
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                  color: themeColor,
                  onRefresh: _loadCars,
                  child: _filtered.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _filtered.length,
                          itemBuilder: (context, index) {
                            final car = _filtered[index];
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8.0),
                              child: CarCardWidget(
                                car: car,
                                enableFavorite: false, // No favorite in manager
                                showPrices: true,
                                onTap: () async {
                                  // Convert map → CarModel
                                  final carModel = CarModel.fromJson(car);

                                  final updatedCar =
                                      await Navigator.push<CarModel>(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          CarDetailScreen(car: carModel),
                                    ),
                                  );

                                  // 🔁 Update locally if returned
                                  if (updatedCar != null) {
                                    setState(() {
                                      final index = _cars.indexWhere((c) =>
                                          c['carid'] == updatedCar.carId);
                                      if (index != -1) {
                                        _cars[index] = updatedCar.toJson();
                                      }

                                      final fIndex = _filtered.indexWhere((c) =>
                                          c['carid'] == updatedCar.carId);
                                      if (fIndex != -1) {
                                        _filtered[fIndex] = updatedCar.toJson();
                                      }
                                    });

                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content:
                                            Text("✅ Car updated successfully!"),
                                        duration: Duration(seconds: 2),
                                      ),
                                    );
                                  }
                                },
                              ),
                            );
                          },
                        ),
                ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.directions_car, color: Colors.grey, size: 70),
            SizedBox(height: 12),
            Text(
              "No cars found",
              style: TextStyle(
                fontSize: 16,
                color: Colors.black54,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 4),
            Text(
              "Try adding a new car or pull to refresh",
              style: TextStyle(color: Colors.black45, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
