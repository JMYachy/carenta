import 'package:flutter/material.dart';

class ManagerProfileStats extends StatelessWidget {
  final int cars;
  final int bookings;
  final int verifications;

  const ManagerProfileStats({
    super.key,
    required this.cars,
    required this.bookings,
    required this.verifications,
  });

  @override
  Widget build(BuildContext context) {
    Widget tile(String title, int value, IconData icon, Color color) {
      return Expanded(
        child: Container(
          height: 96,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: const [
              BoxShadow(
                color: Color(0x15000000),
                blurRadius: 8,
                offset: Offset(0, 2),
              ),
            ],
            border: Border.all(color: const Color(0x11000000)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color),
              const Spacer(),
              Text(
                '$value',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: color,
                ),
              ),
              const SizedBox(height: 2),
              Text(title, style: const TextStyle(color: Colors.black54)),
            ],
          ),
        ),
      );
    }

    return Row(
      children: [
        tile(
          'Cars',
          cars,
          Icons.directions_car_filled,
          const Color(0xFF2563EB),
        ),
        const SizedBox(width: 10),
        tile(
          'Bookings',
          bookings,
          Icons.receipt_long_rounded,
          const Color(0xFF10B981),
        ),
        const SizedBox(width: 10),
        tile(
          'Verifications',
          verifications,
          Icons.verified_user_rounded,
          const Color(0xFFF59E0B),
        ),
      ],
    );
  }
}
