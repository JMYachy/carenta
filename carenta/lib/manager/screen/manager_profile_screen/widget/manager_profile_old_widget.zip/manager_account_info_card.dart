import 'package:flutter/material.dart';

class ManagerAccountInfoCard extends StatefulWidget {
  final String firstName;
  final String lastName;
  final String email;
  final String phone;
  final String createdAt;
  final String lastLogin;
  final Future<void> Function(Map<String, String>) onSave;

  const ManagerAccountInfoCard({
    super.key,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phone,
    required this.createdAt,
    required this.lastLogin,
    required this.onSave,
  });

  @override
  State<ManagerAccountInfoCard> createState() => _ManagerAccountInfoCardState();
}

class _ManagerAccountInfoCardState extends State<ManagerAccountInfoCard> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _fn;
  late final TextEditingController _ln;
  late final TextEditingController _em;
  late final TextEditingController _ph;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _fn = TextEditingController(text: widget.firstName);
    _ln = TextEditingController(text: widget.lastName);
    _em = TextEditingController(text: widget.email);
    _ph = TextEditingController(text: widget.phone);
  }

  @override
  void dispose() {
    _fn.dispose();
    _ln.dispose();
    _em.dispose();
    _ph.dispose();
    super.dispose();
  }

  Future<void> _onSave() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    await widget.onSave({
      'first_name': _fn.text.trim(),
      'last_name': _ln.text.trim(),
      'email': _em.text.trim(),
      'phone_number': _ph.text.trim(),
    });
    if (mounted) setState(() => _saving = false);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Row(
                children: const [
                  Icon(Icons.badge_outlined, color: Colors.black87),
                  SizedBox(width: 8),
                  Text(
                    'Account Information',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Two-column fields that wrap nicely
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  SizedBox(
                    width: 280,
                    child: TextFormField(
                      controller: _fn,
                      decoration: const InputDecoration(
                        labelText: 'First Name',
                      ),
                      validator:
                          (v) => v == null || v.isEmpty ? 'Required' : null,
                    ),
                  ),
                  SizedBox(
                    width: 280,
                    child: TextFormField(
                      controller: _ln,
                      decoration: const InputDecoration(labelText: 'Last Name'),
                      validator:
                          (v) => v == null || v.isEmpty ? 'Required' : null,
                    ),
                  ),
                  SizedBox(
                    width: 280,
                    child: TextFormField(
                      controller: _em,
                      decoration: const InputDecoration(labelText: 'Email'),
                      validator:
                          (v) => v == null || v.isEmpty ? 'Required' : null,
                    ),
                  ),
                  SizedBox(
                    width: 280,
                    child: TextFormField(
                      controller: _ph,
                      decoration: const InputDecoration(
                        labelText: 'Phone Number',
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Joined: ${widget.createdAt}',
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'Last Login: ${widget.lastLogin}',
                      textAlign: TextAlign.end,
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              Align(
                alignment: Alignment.centerRight,
                child: ElevatedButton.icon(
                  onPressed: _saving ? null : _onSave,
                  icon:
                      _saving
                          ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                          : const Icon(Icons.save_outlined),
                  label: const Text('Save'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
