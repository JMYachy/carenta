import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ManagerProfileHeader extends StatefulWidget {
  final String name;
  final String role; // admin | manager
  final String status; // active | inactive | banned | pending
  final String email;
  final String phone;
  final String pictureUrl;
  final String createdAt;
  final String lastLogin;
  final Future<void> Function(String localPath) onUploadPhoto;

  const ManagerProfileHeader({
    super.key,
    required this.name,
    required this.role,
    required this.status,
    required this.email,
    required this.phone,
    required this.pictureUrl,
    required this.createdAt,
    required this.lastLogin,
    required this.onUploadPhoto,
  });

  @override
  State<ManagerProfileHeader> createState() => _ManagerProfileHeaderCardState();
}

class _ManagerProfileHeaderCardState extends State<ManagerProfileHeader> {
  final _picker = ImagePicker();
  File? _localPreview;

  Future<void> _pickImage() async {
    final picked = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
    );
    if (picked != null) {
      setState(() => _localPreview = File(picked.path));
      await widget.onUploadPhoto(picked.path);
    }
  }

  Color _statusColor(String s) {
    switch (s.toLowerCase()) {
      case 'active':
        return const Color(0xFF10B981);
      case 'inactive':
        return Colors.grey;
      case 'banned':
        return const Color(0xFFEF4444);
      case 'pending':
        return const Color(0xFFF59E0B);
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _statusColor(widget.status);
    final initials =
        widget.name.isNotEmpty
            ? widget.name
                .trim()
                .split(' ')
                .map((e) => e.isNotEmpty ? e[0] : '')
                .take(2)
                .join()
            : 'M';

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Top: avatar + name/role/email/status
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Avatar + edit
                Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    CircleAvatar(
                      radius: 36,
                      backgroundColor: const Color(0xFFE8EEF7),
                      backgroundImage:
                          _localPreview != null
                              ? FileImage(_localPreview!)
                              : (widget.pictureUrl.isNotEmpty
                                      ? NetworkImage(widget.pictureUrl)
                                      : null)
                                  as ImageProvider<Object>?,
                      child:
                          (widget.pictureUrl.isEmpty && _localPreview == null)
                              ? Text(
                                initials,
                                style: const TextStyle(
                                  fontSize: 20,
                                  color: Color(0xFF0077B6),
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                              : null,
                    ),
                    InkWell(
                      onTap: _pickImage,
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFF0077B6),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        padding: const EdgeInsets.all(6),
                        child: const Icon(
                          Icons.edit,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 14),

                // Name / role / email / phone
                Expanded(
                  child: Wrap(
                    runSpacing: 4,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Flexible(
                            child: Text(
                              widget.name.isEmpty ? 'Manager' : widget.name,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE8EEF7),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              widget.role[0].toUpperCase() +
                                  widget.role.substring(1),
                              style: const TextStyle(
                                fontSize: 11,
                                color: Color(0xFF1D4ED8),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        widget.email,
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                      if (widget.phone.isNotEmpty)
                        Text(
                          widget.phone,
                          style: TextStyle(color: Colors.grey.shade700),
                        ),
                    ],
                  ),
                ),

                // Status chip
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    widget.status[0].toUpperCase() + widget.status.substring(1),
                    style: TextStyle(
                      color: statusColor,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),
            // Joined + Last login row (wrap for small widths)
            Wrap(
              spacing: 16,
              runSpacing: 6,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.calendar_today,
                      size: 16,
                      color: Colors.black54,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Joined: ${widget.createdAt}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.login_rounded,
                      size: 16,
                      color: Colors.black54,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Last login: ${widget.lastLogin}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
