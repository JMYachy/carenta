import 'package:flutter/material.dart';

class ManagerSecuritySettingCard extends StatelessWidget {
  final bool twoFactorEnabled;
  final int loginAttempts;
  final String lastIp;
  final String lastLogin;
  final Future<void> Function(bool enabled) onToggle2FA;
  final Future<void> Function(String current, String next) onChangePassword;

  const ManagerSecuritySettingCard({
    super.key,
    required this.twoFactorEnabled,
    required this.loginAttempts,
    required this.lastIp,
    required this.lastLogin,
    required this.onToggle2FA,
    required this.onChangePassword,
  });

  @override
  Widget build(BuildContext context) {
    final currentCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    bool local2fa = twoFactorEnabled;

    Future<void> _changePwDialog() async {
      await showDialog(
        context: context,
        builder:
            (ctx) => AlertDialog(
              title: const Text('Change Password'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: currentCtrl,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Current Password',
                    ),
                  ),
                  TextField(
                    controller: newCtrl,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'New Password',
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    await onChangePassword(currentCtrl.text, newCtrl.text);
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: const Text('Update'),
                ),
              ],
            ),
      );
    }

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Icon(Icons.security_outlined, color: Colors.black87),
                SizedBox(width: 8),
                Text(
                  'Security Settings',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Expanded(child: Text('Two-Factor Authentication')),
                StatefulBuilder(
                  builder:
                      (ctx, setSB) => Switch(
                        value: local2fa,
                        onChanged: (v) async {
                          await onToggle2FA(v);
                          setSB(() => local2fa = v);
                        },
                      ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 16,
              runSpacing: 6,
              children: [
                Text(
                  'Login Attempts: $loginAttempts',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Text(
                  'Last IP: $lastIp',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Text(
                  'Last Login: $lastLogin',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton.icon(
                onPressed: _changePwDialog,
                icon: const Icon(Icons.password_outlined),
                label: const Text('Change Password'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
