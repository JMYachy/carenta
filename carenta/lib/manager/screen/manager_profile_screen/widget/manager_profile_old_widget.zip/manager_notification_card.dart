import 'package:flutter/material.dart';

class ManagerNotificationCard extends StatelessWidget {
  final List<Map<String, String>> items;

  const ManagerNotificationCard({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Icon(
                  Icons.notifications_active_outlined,
                  color: Colors.black87,
                ),
                SizedBox(width: 8),
                Text(
                  'Recent Notifications',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (items.isEmpty)
              const Padding(
                padding: EdgeInsets.all(12.0),
                child: Text(
                  'No recent notifications',
                  style: TextStyle(color: Colors.black54),
                ),
              )
            else
              ...items.map(
                (n) => _NotificationTile(
                  title: n['title'] ?? '',
                  time: n['time'] ?? '',
                  desc: n['desc'] ?? '',
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NotificationTile extends StatelessWidget {
  final String title;
  final String time;
  final String desc;

  const _NotificationTile({
    required this.title,
    required this.time,
    required this.desc,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: const CircleAvatar(
        radius: 16,
        child: Icon(Icons.notifications_none, size: 18),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(desc),
      trailing: Text(
        time,
        style: const TextStyle(color: Colors.black45, fontSize: 12),
      ),
    );
  }
}
