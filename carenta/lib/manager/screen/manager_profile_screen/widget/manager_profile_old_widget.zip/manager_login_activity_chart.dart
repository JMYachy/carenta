import 'package:flutter/material.dart';

class ManagerLoginActivityChart extends StatelessWidget {
  final List<int> dailyCounts; // 7 values

  const ManagerLoginActivityChart({super.key, required this.dailyCounts});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: const [
                Icon(Icons.show_chart_rounded, color: Colors.black87),
                SizedBox(width: 8),
                Text(
                  'Login Activity (Last 7 Days)',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 140,
              child: CustomPaint(painter: _LineChartPainter(dailyCounts)),
            ),
            const SizedBox(height: 4),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Mon'),
                Text('Tue'),
                Text('Wed'),
                Text('Thu'),
                Text('Fri'),
                Text('Sat'),
                Text('Sun'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _LineChartPainter extends CustomPainter {
  final List<int> values;
  _LineChartPainter(this.values);

  @override
  void paint(Canvas canvas, Size size) {
    // background panel
    final bg = Paint()..color = const Color(0xFFEFF4FF);
    final panel = RRect.fromRectAndRadius(
      Offset.zero & size,
      const Radius.circular(10),
    );
    canvas.drawRRect(panel, bg);

    if (values.isEmpty) return;

    final maxVal = (values.reduce(
      (a, b) => a > b ? a : b,
    )).toDouble().clamp(1, 9999);
    final dx = size.width / (values.length - 1);
    final path = Path();

    for (int i = 0; i < values.length; i++) {
      final x = i * dx;
      final y =
          size.height -
          (values[i] / maxVal) * (size.height - 16) -
          8; // padding
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    final fill =
        Path.from(path)
          ..lineTo(size.width, size.height)
          ..lineTo(0, size.height)
          ..close();

    final fillPaint =
        Paint()
          ..color = const Color(0xFF2563EB).withOpacity(.16)
          ..style = PaintingStyle.fill;
    final linePaint =
        Paint()
          ..color = const Color(0xFF2563EB)
          ..strokeWidth = 2
          ..style = PaintingStyle.stroke;

    canvas.drawPath(fill, fillPaint);
    canvas.drawPath(path, linePaint);
  }

  @override
  bool shouldRepaint(covariant _LineChartPainter oldDelegate) =>
      oldDelegate.values != values;
}
