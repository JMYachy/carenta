import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:carenta/user/booking_screen/user_booking_screen.dart';

class BookingReceiptScreen extends StatelessWidget {
  final Map<String, dynamic> receipt;
  const BookingReceiptScreen({super.key, required this.receipt});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9F9F9),
      appBar: AppBar(
        title: const Text('E-Receipt'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0.4,
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Scrollable receipt section
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: _buildReceiptContent(context),
                ),
              ),
            ),

            // Fixed bottom buttons
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _generatePDF(context),
                      icon: const Icon(Icons.picture_as_pdf_rounded),
                      label: const Text('Download Receipt'),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.indigo,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const UserBookingScreen(),
                          ),
                          (route) => false,
                        );
                      },
                      icon: const Icon(Icons.done_all_rounded),
                      label: const Text('Go to My Bookings'),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: const Color(0xFFFF5722),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===== RECEIPT CONTENT =====
  Widget _buildReceiptContent(BuildContext context) {
    final currencyFmt = NumberFormat('#,##0.00');
    final total = (receipt['total_amount'] ?? receipt['amount'] ?? 0).toDouble();
    final discount = (receipt['discount_percent'] ?? 0).toDouble();
    final dailyRate = (receipt['daily_rate'] ?? 0).toDouble();
    final days = (receipt['total_days'] ?? 0).toInt();
    final currency = receipt['currency'] ?? 'PHP';
    final symbol = switch (currency) {
      'USD' => '\$',
      'EUR' => '€',
      _ => '₱',
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Center(
          child: Column(
            children: [
              const Icon(Icons.receipt_long_rounded,
                  color: Color(0xFFFF5722), size: 70),
              const SizedBox(height: 8),
              Text(
                'Payment Successful',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                'Receipt No: ${receipt['receipt_no'] ?? '-'}',
                style: const TextStyle(color: Colors.black54),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Divider(thickness: 1),

        _info(context, 'Booking Ref', receipt['reference_no']),
        _info(context, 'Rental ID', receipt['rentalid']),
        _info(context, 'Payment ID', receipt['paymentid']),
        _info(context, 'Method', receipt['method']),
        _info(context, 'Status', receipt['status'] ?? 'pending'),

        const SizedBox(height: 20),
        const Divider(thickness: 1),

        Text(
          "Payment Summary",
          style: Theme.of(context)
              .textTheme
              .titleMedium
              ?.copyWith(fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 10),
        _priceRow('Daily Rate', '$symbol${currencyFmt.format(dailyRate)}'),
        _priceRow('Total Days', '$days'),
        if (discount > 0) _priceRow('Promo Discount', '-$discount%'),
        const Divider(),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Total Amount',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Colors.black87,
              ),
            ),
            Text(
              '$symbol${currencyFmt.format(total)} $currency',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFFFF5722),
              ),
            ),
          ],
        ),

        const SizedBox(height: 30),

        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF3E0),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              const Icon(Icons.info_outline, color: Color(0xFFFF5722)),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  "Your payment will be reviewed and approved by the manager. "
                  "You can check your booking status in 'My Bookings'.",
                  style: TextStyle(
                    color: Colors.grey[800],
                    fontSize: 13.5,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ===== REUSABLE UI COMPONENTS =====
  Widget _info(BuildContext context, String label, dynamic value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(color: Colors.black54)),
            Flexible(
              child: Text(
                value?.toString() ?? '-',
                textAlign: TextAlign.right,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
            ),
          ],
        ),
      );

  Widget _priceRow(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: Colors.black54)),
            Text(value,
                style:
                    const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
          ],
        ),
      );

  // ===== PDF GENERATOR =====
  Future<void> _generatePDF(BuildContext context) async {
    final pdf = pw.Document();
    final currencyFmt = NumberFormat('#,##0.00');
    final total = (receipt['total_amount'] ?? receipt['amount'] ?? 0).toDouble();
    final discount = (receipt['discount_percent'] ?? 0).toDouble();
    final dailyRate = (receipt['daily_rate'] ?? 0).toDouble();
    final days = (receipt['total_days'] ?? 0).toInt();
    final currency = receipt['currency'] ?? 'PHP';
    final symbol = switch (currency) {
      'USD' => '\$',
      'EUR' => '€',
      _ => '₱',
    };

    pdf.addPage(
      pw.Page(
        build: (pw.Context ctx) => pw.Padding(
          padding: const pw.EdgeInsets.all(24),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Center(
                child: pw.Column(children: [
                  pw.Text('CARÉNTA E-RECEIPT',
                      style: pw.TextStyle(
                          fontSize: 20, fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 5),
                  pw.Text(
                    'Generated on ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}',
                    style: const pw.TextStyle(fontSize: 10),
                  ),
                  pw.Divider(),
                ]),
              ),
              pw.Text('Receipt No: ${receipt['receipt_no'] ?? '-'}'),
              pw.Text('Booking Ref: ${receipt['reference_no'] ?? '-'}'),
              pw.Text('Rental ID: ${receipt['rentalid']}'),
              pw.Text('Payment ID: ${receipt['paymentid']}'),
              pw.Text('Payment Method: ${receipt['method'] ?? '-'}'),
              pw.SizedBox(height: 16),
              pw.Divider(),
              pw.Text('Payment Summary',
                  style: pw.TextStyle(
                      fontSize: 14, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 6),
              pw.Text('Daily Rate: $symbol${currencyFmt.format(dailyRate)}'),
              pw.Text('Total Days: $days'),
              if (discount > 0)
                pw.Text('Promo Discount: -$discount%'),
              pw.Divider(),
              pw.Text(
                'Total Amount: $symbol${currencyFmt.format(total)} $currency',
                style: pw.TextStyle(
                    fontSize: 16, fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(height: 20),
              pw.Text(
                'Note: Your payment will be reviewed and approved by the manager. '
                'You can check your booking status in the "My Bookings" section.',
                style: const pw.TextStyle(fontSize: 10),
              ),
            ],
          ),
        ),
      ),
    );

    await Printing.layoutPdf(
      onLayout: (format) => pdf.save(),
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('📄 PDF receipt generated successfully!'),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 2),
      ),
    );
  }
}
