import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:carenta/service/config/service_base_url.dart';

/// Represents the API result for booking + payment creation.
class PostPaymentBookingResult {
  final bool success;
  final String message;
  final int? rentalId;
  final int? paymentId;
  final int? receiptId;
  final String? referenceNo;
  final String? rentalStatus;
  final int? totalDays;
  final double? dailyRate;
  final double? discountPercent;
  final double? totalAmount;

  PostPaymentBookingResult({
    required this.success,
    required this.message,
    this.rentalId,
    this.paymentId,
    this.receiptId,
    this.referenceNo,
    this.rentalStatus,
    this.totalDays,
    this.dailyRate,
    this.discountPercent,
    this.totalAmount,
  });

  factory PostPaymentBookingResult.fromJson(Map<String, dynamic> json) {
    return PostPaymentBookingResult(
      success: json['success'] ?? false,
      message: json['message'] ?? '',
      rentalId: json['rentalid'],
      paymentId: json['paymentid'],
      receiptId: json['receiptid'],
      referenceNo: json['reference_no'],
      rentalStatus: json['rental_status'],
      totalDays: json['total_days'],
      dailyRate: (json['daily_rate'] != null)
          ? double.tryParse(json['daily_rate'].toString())
          : null,
      discountPercent: (json['discount_percent'] != null)
          ? double.tryParse(json['discount_percent'].toString())
          : null,
      totalAmount: (json['total_amount'] != null)
          ? double.tryParse(json['total_amount'].toString())
          : null,
    );
  }
}


/// Handles submitting booking + payment data to the server.
class UserPostPaymentBookingService {
  final http.Client _client;
  UserPostPaymentBookingService({http.Client? client})
      : _client = client ?? http.Client();

  Future<PostPaymentBookingResult> submit(Map<String, dynamic> payload) async {
    final url = ServiceBaseUrl.endpoint('post_payment_booking.php');

    try {
      final res = await _client.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      if (res.statusCode != 200) {
        return PostPaymentBookingResult(
          success: false,
          message: 'HTTP ${res.statusCode}: ${res.reasonPhrase}',
        );
      }

      final data = jsonDecode(res.body);

      if (data is Map<String, dynamic>) {
        return PostPaymentBookingResult.fromJson(data);
      } else {
        return PostPaymentBookingResult(
          success: false,
          message: 'Invalid response format',
        );
      }
    } catch (e) {
      return PostPaymentBookingResult(
        success: false,
        message: 'Error: $e',
      );
    }
  }
}
